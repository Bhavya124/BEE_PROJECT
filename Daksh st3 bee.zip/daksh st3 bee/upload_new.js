const express = require('express');
const fs = require('fs');
const fileUpload = require('express-fileupload');
const app = express();
const cloudinary = require('cloudinary').v2;
const path = require('path');
const port = 3227;

cloudinary.config({
    cloud_name: "dcmslwmv2",
    api_key: "236241538859233",
    api_secret: "nqUDhaGhvThLQu_LaGO1hnOE6Lg",
  });  

app.use(fileUpload({ useTempFiles: true }));
app.use(express.json());
app.use(express.static('public'));
let users = [];

const loadDataFromFile = () => {
    if (fs.existsSync('user_upload.json')) {
        try {
            const fileData = fs.readFileSync('user_upload.json', 'utf-8');
            users = JSON.parse(fileData);
        } catch (error) {
            console.error('Error reading data from file:', error);
        }
    }
};
const saveDataToFile = () => {
    try {
        fs.writeFileSync('user_upload.json', JSON.stringify(users, null, 2));
        console.log('Data successfully saved to index.json');
    } catch (error) {
        console.error('Error saving data to file:', error);
    }
};
loadDataFromFile();
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "user_upload_opt2.html"));
});

app.get("/about", (req, res) => {
    res.send("About Page...");
});
app.post("/upload-music", async (req, res) => {
    let user_id;
    if (users.length === 0) {
        user_id = 1;
    } else {
        user_id = users[users.length - 1].id + 1;
    }

    try {
        const musicFile = req.files.musicF;
        const imgFile = req.files.imgF;

        const musicUpload = await cloudinary.uploader.upload(musicFile.tempFilePath, {
            resource_type: "video"
        });

        const imageUpload = await cloudinary.uploader.upload(imgFile.tempFilePath, {
            resource_type: "image"
        });

        const upload = {
            id: user_id,
            mname: req.body.mName,
            wname: req.body.wName,
            desc: req.body.desc,
            musicUrl: musicUpload.secure_url,
            imgUrl: imageUpload.secure_url
        };

        users.push(upload);
        saveDataToFile();
        console.log(users);
        res.status(200).json("music registered");
    } catch (err) {
        console.error("Cloudinary upload failed:", err);
        res.status(500).json("Upload failed");
        }
});

app.delete("/delete-music", (req, res) => {
    const { mName, wName } = req.body;
    const index = users.findIndex(u => u.mname === mName && u.wname === wName);

    if (index !== -1) {
        users.splice(index, 1);
        saveDataToFile();
        res.status(200).json("Music deleted successfully");
    } else {
        res.status(404).json("Music not found");
    }
});


app.listen(port, () => {
    console.log(`Server Running... http://localhost:${port}`);
});
const statusDiv = document.getElementById('status');

function showMessage(message) {
  statusDiv.innerText = message;
}


document.getElementById('signup-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('signup-username').value;
  const password = document.getElementById('signup-password').value;

  const res = await fetch('http://localhost:3000/signup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ username, password })
  });

  const data = await res.json();
  showMessage(data.message);
});


document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;

  const res = await fetch('http://localhost:3000/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ username, password })
  });

  const data = await res.json();
  showMessage(data.message);
});

document.getElementById('logout-btn').addEventListener('click', async () => {
  const res = await fetch('http://localhost:3000/logout', {
    method: 'POST',
    credentials: 'include'
  });

  const data = await res.json();
  showMessage(data.message);
});

// Play Songs
async function playSong(id) {
  const res = await fetch(`http://localhost:3000/play/${id}`, {
    method: 'GET',
    credentials: 'include'
  });

  const data = await res.json();
  showMessage(data.message);
}

const express = require('express');
const session = require('express-session');
const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = 3000;

//ethe apa middleware nu use kita
app.use(express.json());
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } 
}));


app.use('/', authRoutes);


const { isLoggedIn } = require('./middleware/authMiddleware');
app.get('/profile', isLoggedIn, (req, res) => {
  res.json({ message: `Welcome, ${req.session.user.username}` });
});



app.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ message: 'Logout failed. Try again.' });
    }
    res.clearCookie('connect.sid'); 
    res.json({ message: 'Logged out successfully' });
  });
});


app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});



const { guestPlayLimiter } = require('./middleware/guestLimiter');

app.get('/play/:songId', guestPlayLimiter, (req, res) => {
  const songId = req.params.songId;
  res.json({ message: `🎵 Playing song ID: ${songId}` });
});

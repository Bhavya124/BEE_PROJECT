function guestPlayLimiter(req, res, next) {
    if (req.session.user) {
      // unlimited time apa chala sakde haan
      return next();
    }
  
    // guest user vaste function
    if (!req.session.guestPlayCount) {
      req.session.guestPlayCount = 0;
    }
  
    if (req.session.guestPlayCount >= 3) {
      return res.status(403).json({ message: 'Limit reached. Please log in to continue listening.' });
    }
  
    req.session.guestPlayCount++;
    next();
  }
  
  module.exports = { guestPlayLimiter };
  
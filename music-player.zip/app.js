const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.static('public'));
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));

const upload = multer({ dest: 'public/uploads/' });

let recentlyPlayed = [];
const recentFile = 'recentlyPlayed.json';

if (fs.existsSync(recentFile)) {
  recentlyPlayed = JSON.parse(fs.readFileSync(recentFile));
}

app.get('/', (req, res) => {
  const songs = fs.readdirSync('public/uploads/');
  res.render('index', { songs, recentlyPlayed });
});

app.post('/upload', upload.single('song'), (req, res) => {
  const file = req.file;
  if (!file) return res.send("No file uploaded.");

  const newPath = path.join('public/uploads/', file.originalname);
  fs.renameSync(file.path, newPath);

  res.redirect('/');
});

app.get('/play/:songName', (req, res) => {
  const songName = req.params.songName;

  recentlyPlayed = recentlyPlayed.filter(name => name !== songName);
  recentlyPlayed.unshift(songName);
  if (recentlyPlayed.length > 5) recentlyPlayed.pop();

  fs.writeFileSync(recentFile, JSON.stringify(recentlyPlayed));

  res.send(\`
    <h1>Now Playing: \${songName}</h1>
    <audio controls autoplay>
      <source src="/uploads/\${songName}" type="audio/mpeg">
    </audio>
    <br><a href="/">Back to Home</a>
  \`);
});

app.listen(PORT, () => {
  console.log(\`🎵 Music player running at http://localhost:\${PORT}\`);
});
